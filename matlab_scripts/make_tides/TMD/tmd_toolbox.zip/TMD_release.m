fprintf('TMD release 2.02: 21 July 2010\n');
